import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {IGallery} from '../../../../intefaces/IGallery';
import {Galleries} from '../../../constants/galleries.constant';
import * as moment from 'moment';
import {HttpClient} from '@angular/common/http';
import {httpOptions} from '../../../constants/httpUtils';

@Component({
  selector: 'app-galleries',
  templateUrl: './galleries.component.html',
  styleUrls: ['./galleries.component.scss']
})
export class GalleriesComponent implements OnInit {

  httpOptions = httpOptions;

  title = 'AngularGallery';
  description: string;
  galleries: IGallery[];
  searchValue: any;
  travelYearsSet;
  travelYearsArray = [];
  yearSearch: any = null;
  limit: number;
  start: number;
  end: number;
  currentPage: number;
  numberOfPages: any;
  addGalleryActive: boolean = false;
  gallery: IGallery;

  @Output() clearValues = new EventEmitter();

  onGallerySave(gallery) {
    this.http.post('http://project.usagi.pl/gallery', gallery, this.httpOptions).toPromise().then((response: IGallery) => {
      console.log('success');
      this.setCurrentPage();
      this.galleries.push(response);
      this.numberOfPages = this.calculateNumberOfPages();
      this.addGalleryActive = !this.addGalleryActive;
      this.travelYearsArray = this.createSortedYearsArray();
    }, (errResponse) => {
      console.log('error', errResponse);
    });
    this.searchValue = '';
    this.yearSearch = '';
  }

  toggleFormActive() {
    this.addGalleryActive = !this.addGalleryActive;
  }

  createSortedYearsArray = () => {
    let years = [];
    let yearsSet;
    yearsSet = new Set();
    this.galleries.map(travel => yearsSet.add(moment(travel.dateCreated).format('yyyy')));
    yearsSet.forEach(year => {
      years.push(parseInt(year, 10));
    });
    years = years.sort((a, b) => a - b);
    return years;
  };

  constructor(private http: HttpClient) {
    this.title = 'My travels';
    this.description = 'Website created for front-end technologies at university';
    this.galleries = this.fetchGalleries();
    this.searchValue = '';
    this.createSortedYearsArray();
  }

  fetchGalleries() {
    this.galleries = [];
    this.http.get('http://project.usagi.pl/gallery', this.httpOptions).toPromise().then((response: IGallery[]) => {
      this.galleries = response;
      this.numberOfPages = this.calculateNumberOfPages();
      this.travelYearsArray = this.createSortedYearsArray();
    });
    return this.galleries;
  }

  setSearchValue($event) {
    this.searchValue = $event;
  }

  setSearchYear($event) {
    this.yearSearch = $event;
  }

  exportGalleries() {
    Galleries.forEach((gallery: IGallery) => {
      delete (gallery.galleryId);

      this.http.post('http://project.usagi.pl/gallery', gallery, this.httpOptions).toPromise().then((response: IGallery) => {
        console.log('success');
        this.numberOfPages = this.calculateNumberOfPages();
        this.galleries = this.galleries.concat(response);
        this.travelYearsArray = this.createSortedYearsArray();
      }, (errResponse) => {
        console.log('error', errResponse);
      });
    });
  }

  removeGalleries() {
    this.galleries.forEach((gallery: IGallery) => {
      this.http.post('http://project.usagi.pl/gallery/delete/' +
        gallery.galleryId, {}, this.httpOptions).toPromise().then((response) => {
        this.galleries = [];
        this.numberOfPages = this.calculateNumberOfPages();
        this.setCurrentPage();
        this.travelYearsArray = this.createSortedYearsArray();
        console.log('success');
      }, (errResponse) => {
        console.log('error', errResponse);
      });
    });
  }

  calculateNumberOfPages(): any {
    let numberOfPages = Array(Math.ceil(this.galleries.length /
      this.limit)).fill(1);
    if (numberOfPages[0] == undefined) {
      numberOfPages[0] = 1;
    }
    return numberOfPages;
  }

  removeGallery(galleryId) {
    this.http.post('http://project.usagi.pl/gallery/delete/' + galleryId,
      {}, this.httpOptions).toPromise().then((response) => {
      this.galleries = this.galleries.filter((gallery: IGallery) => {
        return gallery.galleryId !== galleryId;
      });
      this.travelYearsArray = this.createSortedYearsArray();
      this.numberOfPages = this.calculateNumberOfPages();
      if (this.galleries.length % 3 === 0 && this.currentPage != 0) {
        this.setCurrentPage(this.currentPage - 1);
      }
      console.log('success');
    }, (errResponse) => {
      console.log('error', errResponse);
    });
  }

  setCurrentPage(page = 0) {
    this.limit = 3;
    this.currentPage = page;
    this.start = this.currentPage * this.limit;
    this.end = this.start + 3;
    localStorage.setItem('galleryPage', this.currentPage.toString());
  }

  moveBack() {
    this.setCurrentPage(this.currentPage - 1);
  }

  moveForward() {
    this.setCurrentPage(this.currentPage + 1);
  }

  ngOnInit(): void {
    this.http.get('http://project.usagi.pl/gallery',
      this.httpOptions).toPromise().then((response: IGallery[]) => {
      this.galleries = response;
      this.numberOfPages = this.calculateNumberOfPages();
    });
    this.currentPage = parseInt(localStorage.getItem('galleryPage')) || 0;
    this.setCurrentPage(this.currentPage);
  }

}
