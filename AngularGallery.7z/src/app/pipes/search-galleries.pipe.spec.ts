import { SearchGalleriesPipe } from './search-galleries.pipe';

describe('SearchGalleriesPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchGalleriesPipe();
    expect(pipe).toBeTruthy();
  });
});
