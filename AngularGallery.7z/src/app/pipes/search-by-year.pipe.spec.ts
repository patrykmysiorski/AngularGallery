import { SearchByYearPipe } from './search-by-year.pipe';

describe('SearchByYearPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchByYearPipe();
    expect(pipe).toBeTruthy();
  });
});
